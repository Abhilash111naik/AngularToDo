import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/todo';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit{

  
  localItem : string;
  todos: Todo[];
  constructor(){
    this.localItem = localStorage.getItem("todos")|| '{}';

    if(this.localItem == null)
    {
      this.todos = [];
    }
    else
    {
      this.todos = JSON.parse(this.localItem);
    }

  }

  ngOnInit(): void {
      
  }
  deleteToDo(item : Todo){
    console.log(item);
    var index = this.todos.indexOf(item);
    this.todos.splice(index ,1);
    localStorage.setItem("todos", JSON.stringify(this.todos));
  }

  addtoDo(item : Todo){
    console.log(item);
    this.todos.push(item);
    localStorage.setItem("todos",JSON.stringify(this.todos));
  }

  toggletoDo(item: Todo){
  
    var index = this.todos.indexOf(item);
    
    this.todos[index].active = !this.todos[index].active;
    localStorage.setItem("todos",JSON.stringify(this.todos));
    console.log(item); 
  }
}
