import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Todo } from 'src/app/todo';

@Component({
  selector: 'app-todo-item',
  templateUrl: './todo-item.component.html',
  styleUrls: ['./todo-item.component.css']
})
export class TodoItemComponent {
  
  @Input()
  item!: Todo;
  @Input()
  i!: number;

  @Output()
  toDoDelete : EventEmitter<Todo> = new EventEmitter();
  @Output() 
  toDoCheckBox : EventEmitter<Todo> = new EventEmitter();

  constructor(){}

  OnClick(item : Todo) {

    this.toDoDelete.emit(item);
    console.log("OnClick has been trigered")
  }
  onCheckBoxClick(item: Todo){
    console.log(item);
    this.toDoCheckBox.emit(item);
    console.log(item);
  }
  ngOnInit(): void {
      
  }

}
